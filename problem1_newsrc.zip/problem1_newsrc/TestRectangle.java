package problem1_newsrc;

import problem1.Rectangle;

public class TestRectangle {

	public static void main(String[] args) {
		
		Rectangle r1 =new Rectangle(5, 6);
		r1.display();
		Rectangle r2 =new Rectangle(6, 6);
		r2.display();
		Rectangle r3 =new Rectangle(7, 6);
		r3.display();
		Rectangle r4 =new Rectangle(8, 6);
		r4.display();
		Rectangle r5 =new Rectangle(9, 6);
		r5.display();
		
	}
}
